// Background service worker for handling server management and downloads
let serverStatus = false;
let youtubeTabs = new Set();
let downloadQueue = [];
let serverStartAttempts = 0;
const MAX_SERVER_ATTEMPTS = 3;

// Add API testing functionality
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'testAPI') {
        testAPI().then(result => {
            sendResponse({ success: true, data: result });
        }).catch(error => {
            sendResponse({ success: false, error: error.message });
        });
        return true; // Keep message channel open for async response
    }
});

// Function to test API from background script
async function testAPI() {
    try {
        console.log('🧪 Background script testing API...');
        const response = await fetch('http://127.0.0.1:2004/api/v1/status');
        const data = await response.json();
        console.log('✅ Background API test successful:', data);
        return data;
    } catch (error) {
        console.error('❌ Background API test failed:', error);
        throw error;
    }
}

// Track YouTube tabs and server status
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url) {
        if (tab.url.includes('youtube.com') || tab.url.includes('youtu.be')) {
            youtubeTabs.add(tabId);
            checkAndStartServer();
        }
    }
});

chrome.tabs.onRemoved.addListener((tabId) => {
    youtubeTabs.delete(tabId);
    checkServerShutdown();
});

// Check if server should be started
async function checkAndStartServer() {
    if (serverStartAttempts >= MAX_SERVER_ATTEMPTS) {
        console.log('Max server start attempts reached, not attempting to start');
        return;
    }
    
    try {
        // First check if server is already running
        const response = await fetch('http://127.0.0.1:2004/api/v1/status');
        if (response.ok) {
            const data = await response.json();
            console.log('Server is already running:', data);
            serverStatus = true;
            serverStartAttempts = 0;
            
            // Notify all YouTube tabs that server is ready
            notifyTabsServerReady();
            return;
        }
    } catch (error) {
        // Server not running, start it
        console.log('Server not running, attempting to start...');
        await startServer();
    }
}

// Start the Python server automatically
async function startServer() {
    try {
        serverStartAttempts++;
        console.log(`Attempting to start server (attempt ${serverStartAttempts}/${MAX_SERVER_ATTEMPTS})`);
        
        // Try to start server using the available methods
        const success = await tryStartServer();
        
        if (success) {
            serverStatus = true;
            serverStartAttempts = 0;
            console.log('Server started successfully!');
            
            // Notify all YouTube tabs that server is ready
            notifyTabsServerReady();
        } else {
            throw new Error('Failed to start server');
        }
        
    } catch (error) {
        console.error('Failed to start server:', error);
        if (serverStartAttempts >= MAX_SERVER_ATTEMPTS) {
            console.error('Max server start attempts reached');
            // Notify tabs that server start failed
            notifyTabsServerFailed();
        }
    }
}

// Try different methods to start the server
async function tryStartServer() {
    try {
        console.log('Attempting to start server automatically...');
        
        // Method 1: Try to use the VBS script (most reliable on Windows)
        if (navigator.platform.includes('Win')) {
            console.log('Windows detected, trying VBS script...');
            
            // Create a download link to trigger the VBS script
            // This is a workaround since extensions can't directly execute local files
            const vbsUrl = chrome.runtime.getURL('run_server_silent.vbs');
            console.log('VBS script URL:', vbsUrl);
            
            // Try to open the VBS script - user will need to allow it
            chrome.tabs.create({ url: vbsUrl, active: false });
            
            // Wait and check if server starts
            await new Promise(resolve => setTimeout(resolve, 3000));
            
            // Check if server is now running
            const response = await fetch('http://127.0.0.1:2004/api/v1/status');
            if (response.ok) {
                console.log('Server started via VBS script!');
                return true;
            }
        }
        
        // Method 2: Try to show instructions to user
        console.log('Automatic start failed, showing manual instructions...');
        return false;
        
    } catch (error) {
        console.error('Error in tryStartServer:', error);
        return false;
    }
}

// Check if server should be shut down
async function checkServerShutdown() {
    // Only shutdown if no YouTube tabs are open AND no downloads are in progress
    if (youtubeTabs.size === 0 && downloadQueue.length === 0) {
        console.log('No YouTube tabs open and no downloads in progress, considering server shutdown...');
        
        // Wait a bit before shutting down to avoid rapid start/stop
        setTimeout(async () => {
            if (youtubeTabs.size === 0 && downloadQueue.length === 0) {
                console.log('Shutting down server due to inactivity...');
                serverStatus = false;
            }
        }, 30000); // Wait 30 seconds
    }
}

// Notify tabs that server is ready
function notifyTabsServerReady() {
    console.log('Notifying tabs that server is ready...');
    youtubeTabs.forEach(tabId => {
        chrome.tabs.sendMessage(tabId, { action: 'serverReady' }).catch(() => {
            // Tab might not be ready to receive messages, ignore error
        });
    });
}

// Notify tabs that server start failed
function notifyTabsServerFailed() {
    console.log('Notifying tabs that server start failed...');
    youtubeTabs.forEach(tabId => {
        chrome.tabs.sendMessage(tabId, { action: 'serverFailed' }).catch(() => {
            // Tab might not be ready to receive messages, ignore error
        });
    });
}

// Handle messages from content scripts and popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'openPopup') {
        // Open the popup for format selection
        chrome.action.openPopup();
    } else if (request.action === 'startServer') {
        // Handle server startup request
        console.log('Received request to start server');
        checkAndStartServer();
        sendResponse({status: 'starting_server'});
    } else if (request.action === 'checkServerStatus') {
        // Check current server status
        sendResponse({status: serverStatus});
    } else if (request.action === 'addToDownloadQueue') {
        // Add download to queue to prevent server shutdown
        downloadQueue.push(request.taskId);
        sendResponse({status: 'added_to_queue'});
    } else if (request.action === 'removeFromDownloadQueue') {
        // Remove download from queue
        const index = downloadQueue.indexOf(request.taskId);
        if (index > -1) {
            downloadQueue.splice(index, 1);
        }
        checkServerShutdown();
        sendResponse({status: 'removed_from_queue'});
    }
});

// Handle extension installation
chrome.runtime.onInstalled.addListener(() => {
    console.log('Tube Snatcher Pro extension installed');
    console.log('Extension will automatically manage Python backend server');
});

// Handle extension startup
chrome.runtime.onStartup.addListener(() => {
    console.log('Tube Snatcher Pro extension started');
    console.log('Checking for existing YouTube tabs...');
    
    // Check existing tabs for YouTube
    chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
            if (tab.url && (tab.url.includes('youtube.com') || tab.url.includes('youtu.be'))) {
                youtubeTabs.add(tab.id);
            }
        });
        
        if (youtubeTabs.size > 0) {
            checkAndStartServer();
        }
    });
});

// Periodic server status check
setInterval(async () => {
    if (youtubeTabs.size > 0 || downloadQueue.length > 0) {
        try {
            const response = await fetch('http://127.0.0.1:2004/api/v1/status');
            if (response.ok) {
                const data = await response.json();
                if (!serverStatus) {
                    console.log('Server detected as running during periodic check');
                    serverStatus = true;
                    serverStartAttempts = 0;
                    notifyTabsServerReady();
                }
            } else {
                if (serverStatus) {
                    console.log('Server no longer responding during periodic check');
                    serverStatus = false;
                }
                // Try to restart server if it went down
                if (youtubeTabs.size > 0) {
                    checkAndStartServer();
                }
            }
        } catch (error) {
            if (serverStatus) {
                console.log('Server connection failed during periodic check');
                serverStatus = false;
            }
            // Try to restart server if it went down
            if (youtubeTabs.size > 0) {
                checkAndStartServer();
            }
        }
    }
}, 10000); // Check every 10 seconds
