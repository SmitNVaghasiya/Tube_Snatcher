// Popup script for handling user interactions
document.addEventListener('DOMContentLoaded', function() {
    // Get DOM elements
    const status = document.getElementById('status');
    const videoInfo = document.getElementById('videoInfo');
    const thumbnail = document.getElementById('thumbnail');
    const videoTitle = document.getElementById('videoTitle');
    const videoDuration = document.getElementById('videoDuration');
    const formatSelection = document.getElementById('formatSelection');
    const formats = document.getElementById('formats');
    const downloadLocation = document.getElementById('downloadLocation');
    const downloadSection = document.getElementById('downloadSection');
    const downloadBtn = document.getElementById('downloadBtn');
    const progress = document.getElementById('progress');
    const progressFill = document.getElementById('progressFill');
    const progressText = document.getElementById('progressText');
    const error = document.getElementById('error');
    const errorMessage = document.getElementById('errorMessage');
    const retryBtn = document.getElementById('retryBtn');
    const queueStatus = document.getElementById('queueStatus');
    
    // Download location elements
    const defaultLocation = document.getElementById('defaultLocation');
    const customLocation = document.getElementById('customLocation');
    const customPathInput = document.getElementById('customPathInput');
    const customPath = document.getElementById('customPath');
    const browseBtn = document.getElementById('browseBtn');

    let selectedFormat = null;
    let selectedLocation = 'default';
    let currentVideo = null;
    let downloadTaskId = null;
    let progressInterval = null;

    // Initialize popup
    init();
    
    // Add new feature: Download location selector
    loadDownloadLocations();
    
    // Add new feature: History display
    loadDownloadHistory();

    function init() {
        // Get current video info from storage
        chrome.storage.local.get(['currentVideo'], function(result) {
            if (result.currentVideo) {
                currentVideo = result.currentVideo;
                displayVideoInfo(currentVideo);
                fetchVideoFormats(currentVideo.url);
                showSection(formatSelection);
                showSection(downloadLocation);
                showSection(downloadSection);
                status.textContent = 'Ready to download';
            } else {
                status.textContent = 'No video selected. Go to a YouTube video page and click the Download button.';
            }
        });

        // Add event listeners
        downloadBtn.addEventListener('click', handleDownload);
        retryBtn.addEventListener('click', init);
        
        // Download location event listeners
        defaultLocation.addEventListener('change', handleLocationChange);
        customLocation.addEventListener('change', handleLocationChange);
        browseBtn.addEventListener('click', handleBrowseClick);
        
        // Load saved location preference
        loadLocationPreference();
    }

    function displayVideoInfo(video) {
        thumbnail.src = video.thumbnail;
        videoTitle.textContent = video.title;
        videoDuration.textContent = 'Duration: Loading...';
        showSection(videoInfo);
    }

    // Handle download location changes
    function handleLocationChange() {
        if (defaultLocation.checked) {
            selectedLocation = 'default';
            customPathInput.style.display = 'none';
        } else if (customLocation.checked) {
            selectedLocation = 'custom';
            customPathInput.style.display = 'block';
            customPath.focus();
        }
        
        // Save location preference
        saveLocationPreference();
    }

    // Handle browse button click
    function handleBrowseClick() {
        // Note: Chrome extensions cannot directly open file picker
        // This is a placeholder for future implementation
        customPath.focus();
        customPath.select();
        
        // Show helpful message
        alert('Please enter the full path to your desired download folder.\n\nExample paths:\nWindows: C:\\Videos\\YouTube\nmacOS: /Users/username/Videos/YouTube\nLinux: /home/username/Videos/YouTube');
    }

    // Load saved location preference
    function loadLocationPreference() {
        chrome.storage.local.get(['downloadLocation'], function(result) {
            if (result.downloadLocation) {
                selectedLocation = result.downloadLocation.type;
                if (selectedLocation === 'custom' && result.downloadLocation.path) {
                    customPath.value = result.downloadLocation.path;
                    customLocation.checked = true;
                    customPathInput.style.display = 'block';
                } else {
                    defaultLocation.checked = true;
                }
            }
        });
    }

    // Save location preference
    function saveLocationPreference() {
        const locationData = {
            type: selectedLocation,
            path: selectedLocation === 'custom' ? customPath.value : null
        };
        chrome.storage.local.set({ downloadLocation: locationData });
    }

    // Fetch video formats from Python backend
    async function fetchVideoFormats(url) {
        try {
            status.textContent = 'Fetching video formats...';
            
            const formData = new FormData();
            formData.append('url', url);
            formData.append('format', 'mp4');
            
            const response = await fetch('http://127.0.0.1:2004/api/v1/fetch-details', {
                method: 'POST',
                body: formData
            });
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const data = await response.json();
            
            if (data.error) {
                throw new Error(data.error);
            }
            
            // Display formats
            displayFormats(data.formats || []);
            status.textContent = 'Ready to download';
            
        } catch (error) {
            console.error('Failed to fetch formats:', error);
            const errorMsg = error.message.includes('fetch') ? 
                'Server not running. Please start the Python backend first.' : 
                error.message;
            status.textContent = 'Failed to fetch video formats';
            showError(errorMsg);
        }
    }

    function displayFormats(formatList) {
        formats.innerHTML = '';
        
        if (!formatList || formatList.length === 0) {
            formats.innerHTML = '<p>No formats available</p>';
            return;
        }
        
        // Filter and sort formats by quality
        const suitableFormats = filterAndSortFormats(formatList);
        
        // Display formats
        suitableFormats.forEach((format, index) => {
            const formatOption = createFormatOption(format, index === 0);
            formats.appendChild(formatOption);
        });

        // Set default selected format
        if (suitableFormats.length > 0) {
            selectedFormat = suitableFormats[0].format_id;
            document.querySelector('.format-option').classList.add('selected');
        }
    }

    function filterAndSortFormats(formatList) {
        // Filter formats to show only suitable qualities
        const suitableFormats = formatList.filter(format => {
            if (!format.resolution) return false;
            
            const height = extractHeight(format.resolution);
            return height >= 360 && height <= 1440;
        });

        // Sort by quality (highest first)
        suitableFormats.sort((a, b) => {
            const heightA = extractHeight(a.resolution);
            const heightB = extractHeight(b.resolution);
            return heightB - heightA;
        });

        // If no suitable formats found, show all formats
        return suitableFormats.length > 0 ? suitableFormats : formatList;
    }

    function createFormatOption(format, isDefault) {
        const formatOption = document.createElement('div');
        formatOption.className = 'format-option';
        
        // Create quality display
        const qualityText = format.resolution || format.format_id;
        const detailsText = createFormatDetailsText(format);
        
        formatOption.innerHTML = `
            <input type="radio" name="format" value="${format.format_id}" ${isDefault ? 'checked' : ''}>
            <div class="format-info">
                <div class="format-quality">${qualityText}</div>
                <div class="format-details">${detailsText || 'Best available quality'}</div>
            </div>
        `;
        
        formatOption.addEventListener('change', function() {
            selectedFormat = format.format_id;
            // Update selected state
            document.querySelectorAll('.format-option').forEach(opt => opt.classList.remove('selected'));
            formatOption.classList.add('selected');
        });
        
        return formatOption;
    }

    function createFormatDetailsText(format) {
        const parts = [];
        
        if (format.filesize) {
            parts.push(format.filesize);
        }
        if (format.ext) {
            parts.push(format.ext.toUpperCase());
        }
        if (format.format_note && format.format_note !== 'N/A') {
            parts.push(format.format_note);
        }
        
        return parts.join(' • ');
    }

    function extractHeight(resolution) {
        if (!resolution) return 0;
        
        // Try to extract height from various formats
        const heightMatch = resolution.match(/(\d+)x(\d+)/);
        if (heightMatch) {
            return parseInt(heightMatch[2]);
        }
        
        const qualityMatch = resolution.match(/(\d+)p/);
        if (qualityMatch) {
            return parseInt(qualityMatch[1]);
        }
        
        return 0;
    }

    async function handleDownload() {
        if (!selectedFormat || !currentVideo) {
            showError('No format selected');
            return;
        }

        // Validate custom path if selected
        if (selectedLocation === 'custom' && (!customPath.value || customPath.value.trim() === '')) {
            showError('Please enter a valid download path');
            customPath.focus();
            return;
        }

        try {
            downloadBtn.disabled = true;
            downloadBtn.innerHTML = `
                <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                </svg>
                <span>Adding to Queue...</span>
            `;
            
            showSection(progress);
            hideSection(error);

            // Prepare download data
            const downloadData = {
                url: currentVideo.url,
                format_id: selectedFormat,
                format: 'mp4',
                download_location: selectedLocation === 'custom' ? customPath.value.trim() : 'default'
            };

            // Send download request to Python server
            const formData = new FormData();
            formData.append('url', downloadData.url);
            formData.append('format_id', downloadData.format_id);
            formData.append('format', downloadData.format);
            formData.append('download_location', downloadData.download_location);

            const response = await fetch('http://127.0.0.1:2004/api/v1/download', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.detail || `HTTP ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();
            downloadTaskId = result.task_id;
            
            // Add to background script queue to prevent server shutdown
            chrome.runtime.sendMessage({
                action: 'addToDownloadQueue',
                taskId: downloadTaskId
            });
            
            // Show queue status
            if (queueStatus) {
                const queueStatusText = queueStatus.querySelector('#queueStatusText');
                if (queueStatusText) {
                    queueStatusText.textContent = `Added to queue (Position: ${result.queue_position})`;
                }
                queueStatus.style.display = 'block';
            }
            
            // Start monitoring progress
            startProgressMonitoring();
            
        } catch (error) {
            console.error('Download error:', error);
            showError(error.message);
            resetUI();
        }
    }

    function startProgressMonitoring() {
        if (progressInterval) {
            clearInterval(progressInterval);
        }

        progressInterval = setInterval(async () => {
            try {
                const response = await fetch('http://127.0.0.1:2004/api/v1/queue');
                if (response.ok) {
                    const queueData = await response.json();
                    
                    // Find our task
                    let ourTask = queueData.active.find(task => task.id === downloadTaskId);
                    
                    if (ourTask) {
                        updateProgress(ourTask.progress, 'Downloading...');
                        if (ourTask.status === 'completed') {
                            clearInterval(progressInterval);
                            showSuccess('Download completed!');
                            // Remove from background script queue
                            chrome.runtime.sendMessage({
                                action: 'removeFromDownloadQueue',
                                taskId: downloadTaskId
                            });
                            return;
                        } else if (ourTask.status === 'failed') {
                            clearInterval(progressInterval);
                            showError(ourTask.error || 'Download failed');
                            // Remove from background script queue
                            chrome.runtime.sendMessage({
                                action: 'removeFromDownloadQueue',
                                taskId: downloadTaskId
                            });
                            return;
                        }
                    }
                    
                    // Check queue position
                    const queuePosition = queueData.queue.findIndex(task => task.id === downloadTaskId);
                    if (queuePosition !== -1) {
                        updateProgress(0, `Waiting in queue (Position: ${queuePosition + 1})`);
                    }
                }
            } catch (error) {
                console.error('Progress check failed:', error);
            }
        }, 2000);
    }

    function updateProgress(percent, text) {
        progressFill.style.width = percent + '%';
        progressText.textContent = text;
    }

    function showSuccess(message) {
        status.textContent = message;
        hideSection(progress);
        hideSection(error);
        resetUI();
    }

    function showError(message) {
        errorMessage.textContent = message;
        showSection(error);
        hideSection(progress);
    }

    function resetUI() {
        downloadBtn.disabled = false;
        downloadBtn.innerHTML = `
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                <path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/>
            </svg>
            Download
        `;
        hideSection(progress);
        progressFill.style.width = '0%';
        progressText.textContent = '0%';
        
        if (queueStatus) {
            queueStatus.style.display = 'none';
        }
    }

    function showSection(section) {
        if (section) section.style.display = 'block';
    }

    function hideSection(section) {
        if (section) section.style.display = 'none';
    }
    
    // ===== NEW FEATURES =====
    
    // Download Location Selector
    async function loadDownloadLocations() {
        try {
            const response = await fetch('http://127.0.0.1:2004/api/v1/download-locations');
            if (response.ok) {
                const data = await response.json();
                createLocationSelector(data.locations);
            }
        } catch (error) {
            console.log('Could not load download locations:', error);
        }
    }
    
    function createLocationSelector(locations) {
        if (!locations || locations.length === 0) return;
        
        // Create a dropdown for location selection
        const locationSelect = document.createElement('select');
        locationSelect.id = 'locationSelector';
        locationSelect.className = 'location-select';
        
        locations.forEach(location => {
            const option = document.createElement('option');
            option.value = location.path;
            option.textContent = location.name;
            if (location.is_default) option.selected = true;
            locationSelect.appendChild(option);
        });
        
        // Add to download location section
        const locationSection = document.getElementById('downloadLocation');
        if (locationSection) {
            locationSection.appendChild(locationSelect);
        }
    }
    
    // Progress Tracking with Task ID
    async function trackDownloadProgress(taskId) {
        const updateProgress = async () => {
            try {
                const response = await fetch(`http://127.0.0.1:2004/api/v1/task/${taskId}`);
                if (response.ok) {
                    const task = await response.json();
                    
                    // Update UI with progress
                    updateProgress(task.progress);
                    updateStatus(task.status);
                    
                    if (task.status === 'completed' || task.status === 'failed') {
                        clearInterval(progressInterval);
                        handleDownloadComplete(task);
                    }
                }
            } catch (error) {
                console.error('Error tracking progress:', error);
            }
        };
        
        const progressInterval = setInterval(updateProgress, 1000);
        updateProgress(); // Initial call
    }
    
    function updateStatus(status) {
        if (status === 'completed') {
            showSuccess('Download completed!');
        } else if (status === 'failed') {
            showError('Download failed');
        }
    }
    
    function handleDownloadComplete(task) {
        if (task.status === 'completed') {
            showSuccess(`Download completed: ${task.filename}`);
        } else {
            showError(task.error || 'Download failed');
        }
    }
    
    // Download History Display
    async function loadDownloadHistory() {
        try {
            const response = await fetch('http://127.0.0.1:2004/api/v1/history');
            if (response.ok) {
                const data = await response.json();
                displayHistory(data.history);
            }
        } catch (error) {
            console.log('Could not load download history:', error);
        }
    }
    
    function displayHistory(history) {
        if (!history || history.length === 0) return;
        
        // Create history container if it doesn't exist
        let historyContainer = document.getElementById('historyContainer');
        if (!historyContainer) {
            historyContainer = document.createElement('div');
            historyContainer.id = 'historyContainer';
            historyContainer.className = 'history-container';
            document.body.appendChild(historyContainer);
        }
        
        historyContainer.innerHTML = '';
        
        // Add history header
        const header = document.createElement('h3');
        header.textContent = 'Download History';
        header.className = 'history-header';
        historyContainer.appendChild(header);
        
        // Display history items
        history.forEach(task => {
            const item = createHistoryItem(task);
            historyContainer.appendChild(item);
        });
    }
    
    function createHistoryItem(task) {
        const item = document.createElement('div');
        item.className = 'history-item';
        item.innerHTML = `
            <div class="history-title">${task.filename || 'Unknown'}</div>
            <div class="history-status ${task.status}">${task.status}</div>
            <div class="history-time">${new Date(task.created_at).toLocaleString()}</div>
        `;
        return item;
    }
    
    // Function to open history page
    function openHistory() {
        chrome.tabs.create({
            url: chrome.runtime.getURL('history.html')
        });
    }
    
    // Make openHistory globally accessible
    window.openHistory = openHistory;
});
